package finalActivity.finalActivityEcommerce.testComponents;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import finalActivity.finalActivityEcommerce.pageObjects.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {

    public WebDriver driver;

    public WebDriver initializeDriver() throws IOException {
        Properties prop = new Properties();
        FileInputStream fIS = new FileInputStream(System.getProperty("user.dir")
                + "//src//test//java//finalActivity//finalActivityEcommerce//data//GlobalData.properties");
        prop.load(fIS);

        String browserName = System.getProperty("browser") != null ? System.getProperty("browser")
                : prop.getProperty("browser");
        
        System.out.println("Selected Browser: " + browserName);

        boolean isHeadless = browserName.toLowerCase().contains("headless");

        if (browserName.contains("chrome")) {
            ChromeOptions chromeOptions = new ChromeOptions();
            if (isHeadless) {
                chromeOptions.addArguments("--headless");
            }
            System.out.println("Using WebDriverManager for Chrome.");
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver(chromeOptions);
        } 
        else if (browserName.contains("firefox")) {
            FirefoxOptions firefoxOptions = new FirefoxOptions();
            if (isHeadless) {
                firefoxOptions.addArguments("--headless");
            }
            System.out.println("Using WebDriverManager for Firefox.");
            WebDriverManager.firefoxdriver().setup();
            driver = new FirefoxDriver(firefoxOptions);
        } 
        else if (browserName.contains("edge") || browserName.equalsIgnoreCase("edge-headless")) {
            EdgeOptions edgeOptions = new EdgeOptions();
            if (isHeadless) {
                edgeOptions.addArguments("--headless");
            }
            System.out.println("Using WebDriverManager for Edge.");
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver(edgeOptions);
        } 
        else {
            throw new RuntimeException("Invalid browser name provided: " + browserName);
        }

        // Set browser properties if driver is initialized
        if (driver != null) {
            driver.manage().window().setSize(new Dimension(1440, 900));
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            System.out.println(browserName + " WebDriver initialized successfully.");
        }

        return driver;
    }


    @BeforeMethod(alwaysRun = true)
    public void launchApplication() throws IOException {
        driver = initializeDriver(); // Now assigning to the global driver
        LoginPage loginPage = new LoginPage(driver);
        loginPage.goTo();
    }
    


    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
