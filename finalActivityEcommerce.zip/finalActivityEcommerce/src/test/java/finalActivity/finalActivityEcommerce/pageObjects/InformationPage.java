package finalActivity.finalActivityEcommerce.pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.fasterxml.jackson.databind.JsonNode;

import finalActivity.finalActivityEcommerce.abstractComponent.AbstractComponents;
import finalActivity.finalActivityEcommerce.data.DataConverter;

/**
 * This class represents the Information Page in the E-Commerce application.
 * It provides methods to interact with the information page elements such as the checkout process, 
 * filling out the form, checking for errors, and more.
 */
public class InformationPage extends AbstractComponents {

    private WebDriver driver;

    @FindBy(id = "checkout")
    private WebElement checkoutButton;

    @FindBy(id = "first-name")
    private WebElement firstNameElement;

    @FindBy(id = "last-name")
    private WebElement lastNameElement;

    @FindBy(id = "postal-code")
    private WebElement postalCodeElement;

    @FindBy(id = "cancel")
    private WebElement cancelButton;

    @FindBy(id = "continue")
    private WebElement continueButton;

    @FindBy(xpath = "//h3")
    private WebElement errorMessageElement;

    @FindBy(className = "header_secondary_container")
    private WebElement headerContainer;

    /**
     * Constructor to initialize the InformationPage object.
     * 
     * @param driver WebDriver instance to interact with the browser.
     */
    public InformationPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * This method checks the utilities of the Information Page.
     * It performs login, adds items to the cart, navigates to the cart page, 
     * and verifies the presence of elements and URLs.
     * 
     * @return true if all checks pass, false otherwise.
     * @throws IOException If there is an error during the operation.
     * @throws InterruptedException If the thread is interrupted.
     */
    public boolean checkInformationUtilities() throws IOException, InterruptedException {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginAccount();
        AddToCart addToCart = new AddToCart(driver);
        addToCart.addToCart(3);  // Add 3 items to the cart
        goToCartPage();

        // Perform checks on the Information Page
        if (checkInformationPageURL() && checkElementVisibility() && checkCartPageURL()) {
            AbstractComponents.logStep("TC[Checkout Process Verification] : ✅ URL matches the expected url in the checkout page.");
            AbstractComponents.logStep("TC[Checkout Process Verification] : ✅ Elements are visible in the checkout process verification.");
            AbstractComponents.logStep("TC[Checkout Process Verification] : ✅ System redirects to product lisitng page after clicking cancel button.");

        	return true;
            
            
        }
        return false;
    }

    /**
     * Verifies the URL of the Cart Page after clicking the cancel button.
     * 
     * @return true if the URL matches, false otherwise.
     * @throws IOException If there is an error checking the URL.
     */
    public boolean checkCartPageURL() throws IOException {
        cancelButton.click();
        return checkCurrentURL(0);  // 0 refers to the cart page URL check
    }

    /**
     * Verifies the URL of the Information Page after clicking the checkout button.
     * 
     * @return true if the URL matches, false otherwise.
     * @throws IOException If there is an error checking the URL.
     */
    public boolean checkInformationPageURL() throws IOException {
        checkoutButton.click();
        return checkCurrentURL(1);  // 1 refers to the information page URL check
    }

    /**
     * Checks the visibility of critical elements such as header and input fields.
     * 
     * @return true if all elements are visible, false otherwise.
     */
    public boolean checkElementVisibility() {
        try {
            waitForWebElementAppear(headerContainer);
            waitForWebElementAppear(firstNameElement);
            waitForWebElementAppear(lastNameElement);
            waitForWebElementAppear(postalCodeElement);
            waitForWebElementAppear(cancelButton);
            return true;
        } catch (Exception e) {
            System.err.println("Error during visibility check: " + e.getMessage());
            return false;
        }
    }

    /**
     * Tests the checkout process by entering invalid data and verifying if the expected error message is displayed.
     * 
     * @param firstName The first name to enter.
     * @param lastName  The last name to enter.
     * @param postalCode The postal code to enter.
     * @param errorMessage The expected error message.
     * @return true if the error message is displayed, false otherwise.
     * @throws IOException If an error occurs during checkout.
     * @throws InterruptedException If the thread is interrupted.
     */
    public boolean errorCheckOutPage(String firstName, String lastName, String postalCode, String errorMessage)
         throws IOException, InterruptedException {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginAccount();
        AddToCart addToCart = new AddToCart(driver);
        addToCart.addToCart(3);
        goToCartPage();
        
        checkoutButton.click();
        fillOutDataExcel(firstName, lastName, postalCode);
        
        waitForWebElementAppear(errorMessageElement);
        System.out.println(errorMessageElement.getText());
        System.out.println(errorMessage);
        // Return true if the error message matches the expected message
        return errorMessageElement.getText().contains(errorMessage);
    }

    /**
     * Fills out the checkout form with the provided data and submits the form.
     * 
     * @param firstName The first name to enter.
     * @param lastName The last name to enter.
     * @param postalCode The postal code to enter.
     */
    public void fillOutDataExcel(String firstName, String lastName, String postalCode) {
    	firstNameElement.sendKeys(firstName);
        lastNameElement.sendKeys(lastName);
        postalCodeElement.sendKeys(postalCode);
        continueButton.click();
    }
    
    public void fillOutData() {
    	 String filePath = "userInformation.json";
         JsonNode firstData = DataConverter.getFirstJsonObject(filePath);
         String firstName = (firstData != null) ? firstData.get("firstName").asText() : "";
         String lastName = (firstData != null) ? firstData.get("lastName").asText() : "";
         String postalCode = (firstData != null) ? firstData.get("postalCode").asText() : "";
    	
    	firstNameElement.sendKeys(firstName);
        lastNameElement.sendKeys(lastName);
        postalCodeElement.sendKeys(postalCode);
        continueButton.click();
    }

    /**
     * Verifies the success of the checkout process by reading user information from a JSON file,
     * filling out the checkout form, and returning the items in the cart after successful checkout.
     * 
     * @return A list of cart items.
     * @throws IOException If there is an error retrieving user data from the JSON file.
     * @throws InterruptedException If the thread is interrupted.
     */
    public List<String> successCheckOutPage() throws IOException, InterruptedException {
        // Fetching necessary data from JSON
     
        // Perform login and add items to the cart
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginAndCheckElementVisibility();
        AddToCart addToCart = new AddToCart(driver);
        addToCart.addToCart(3);
        goToCartPage();

        CartPage cartPage = new CartPage(driver);
        List<String> cartItems = cartPage.getCartItems();

        // Checkout process
        checkoutButton.click();
        
        fillOutData();
        AbstractComponents.logStep("TC[Checkout Process Verification] : ✅ User was able to proceed with all elements correctly filled.");

        return cartItems;  // Return the cart items after successful checkout
    }
}
