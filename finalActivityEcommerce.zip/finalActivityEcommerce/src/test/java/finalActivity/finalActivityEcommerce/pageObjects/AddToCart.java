package finalActivity.finalActivityEcommerce.pageObjects;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fasterxml.jackson.databind.JsonNode;

import finalActivity.finalActivityEcommerce.abstractComponent.AbstractComponents;
import finalActivity.finalActivityEcommerce.data.DataConverter;

import java.time.Duration;

public class AddToCart extends AbstractComponents {

    // WebDriver instance for interacting with the browser
    WebDriver driver;

    // Constructor initializes the WebDriver and PageFactory
    public AddToCart(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Web elements for interacting with the UI components
    @FindBy(xpath = "//button[contains(text(), 'Add to cart')]")
    private List<WebElement> addToCartButtons;

    @FindBy(xpath = "//button[contains(text(), 'Remove')]")
    private List<WebElement> removeButtons;

    @FindBy(className = "shopping_cart_badge")
    private WebElement shoppingBadge;

    @FindBy(className = "bm-menu")
    private WebElement burgerContainer;

    @FindBy(id = "inventory_sidebar_link")
    private WebElement sideBarLink;

    @FindBy(id = "about_sidebar_link")
    private WebElement aboutLink;

    @FindBy(id = "logout_sidebar_link")
    private WebElement logoutLink;

    @FindBy(id = "reset_sidebar_link")
    private WebElement resetLink;

    /**
     * Adds products to the cart until the specified number of products is added.
     * @param productNumber The number of products to add to the cart.
     * @return boolean true if the correct number of products were added, false otherwise.
     */
    public boolean addToCart(int productNumber) {
        removeAllProducts(); // Ensure cart is empty before adding new products

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JsonNode productData = DataConverter.getJsonData(); // Load product data from JSON

        // Check if product data is empty
        if (productData == null || productData.size() == 0) {
            System.err.println("Product JSON data is empty.");
            return false;
        }

        int addedCount = 0;

        // Iterate over the product data and add products to the cart
        for (JsonNode product : productData) {
            int productId = product.get("id").asInt(); // Get product ID
            
            // Skip products beyond the given productNumber limit
            if (productId >= productNumber) {
                continue;
            }

            String productName = product.get("name").asText();
            System.out.println("Looking for product: " + productName + " (ID: " + productId + ")");

            try {
                // Locate the product element using its name
                WebElement productElement = driver.findElement(By.xpath("//div[contains(text(), '" + productName + "')]"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", productElement);

                // Find and click the "Add to Cart" button within the same container
                WebElement addToCartButton = productElement.findElement(By.xpath("./ancestor::div[contains(@class, 'inventory_item')]//button[contains(text(), 'Add to cart')]"));
                addToCartButton.click();
                System.out.println("Added product: " + productName);

                // Wait for the button to change to 'Remove' after adding the product
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(), 'Remove')]")));

                addedCount++; // Increment the added count
                if (addedCount == productNumber) {
                    break; // Stop once we reach the desired number of products
                }
            } catch (NoSuchElementException e) {
                System.err.println("Could not find product: " + productName);
            }
        }

        // Verify the number of products in the cart
        int productAdded = getShoppingBadgeNumber();
        System.out.println("Total products in cart: " + productAdded);

        // Return true if the correct number of products were added
        return productAdded == productNumber;
    }

    /**
     * Checks if all elements in the burger menu are visible.
     * @return boolean true if all elements are present and visible, false otherwise.
     */
    public boolean checkBurgerMenuElementsExists() {
        try {
            // Wait for each element in the burger menu to appear
            waitForWebElementAppear(sideBarLink);
            waitForWebElementAppear(aboutLink);
            waitForWebElementAppear(logoutLink);
            waitForWebElementAppear(resetLink);
            return true;
        } catch (Exception e) {
            System.out.println("Error checking burger menu elements: " + e.getMessage());
            return false;
        }
    }

    /**
     * Removes all products from the cart by clicking the "Remove" button for each item.
     */
    public void removeAllProducts() {
        while (true) {
            // Refresh the removeButtons list dynamically before each iteration
            List<WebElement> removeButtons = driver.findElements(By.xpath("//button[contains(text(), 'Remove')]"));

            if (removeButtons.isEmpty()) {
                System.out.println("No more products to remove.");
                break;
            }

            // Click the first remove button
            WebElement removeButton = removeButtons.get(0);
            removeButton.click();
            // Wait for the remove button to disappear from the UI
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
            wait.until(ExpectedConditions.stalenessOf(removeButton));

            System.out.println("Removed one product from the cart.");
        }
        System.out.println("All products removed.");
    } 
}
