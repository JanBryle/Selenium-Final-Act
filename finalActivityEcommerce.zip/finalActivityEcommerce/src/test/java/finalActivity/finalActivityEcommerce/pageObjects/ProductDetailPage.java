package finalActivity.finalActivityEcommerce.pageObjects;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fasterxml.jackson.databind.JsonNode;

import finalActivity.finalActivityEcommerce.abstractComponent.AbstractComponents;

public class ProductDetailPage extends AbstractComponents {
    private WebDriver driver;
    private static final Logger LOGGER = Logger.getLogger(ProductDetailPage.class.getName());

    public ProductDetailPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(className = "inventory_details_name")
    private WebElement productName;

    @FindBy(xpath = "//div[@class='inventory_details_img_container']//img")
    private WebElement productImage;

    @FindBy(className = "inventory_details_desc")
    private WebElement productDescription;

    @FindBy(className = "inventory_details_price")
    private WebElement productPrice;
    
    @FindBy(xpath = "//button[contains(text(), 'Add to cart')]")
    private WebElement addToCartButton;

    @FindBy(xpath = "//button[contains(text(), 'Remove')]")
    private WebElement removeButton;

    @FindBy(className = "shopping_cart_badge")
    private WebElement shoppingBadge;
    
    /**
     * Verifies the product detail page by clicking on the product and checking the URL.
     *
     * @param product The product JSON object containing the product details.
     * @return boolean indicating whether the URL is correct.
     */
    public boolean verifyProductDetailPage(JsonNode product) {
        String expectedUrl = product.get("url").asText();
        String productName = product.get("name").asText();

        WebElement productLink = findProductLink(productName);
        
        if (productLink != null) {
            clickProductLink(productLink);

            String currentUrl = driver.getCurrentUrl();
            return validateUrl(currentUrl, expectedUrl, productName);
 
        } else {
            LOGGER.warning("Product link not found for " + productName);
            return false;
        }
    }

    /**
     * Finds the product link by its name.
     *
     * @param productName The name of the product.
     * @return The WebElement representing the product link.
     */
    private WebElement findProductLink(String productName) {
        try {
            return driver.findElement(By.linkText(productName));
        } catch (NoSuchElementException e) {
            LOGGER.warning("Product link not found for " + productName);
            return null;
        }
    }

    /**
     * Clicks the product link.
     *
     * @param productLink The WebElement representing the product link.
     */
    private void clickProductLink(WebElement productLink) {
        productLink.click();
        LOGGER.info("Clicked on product link.");
    }

    /**
     * Validates if the current URL matches the expected URL.
     *
     * @param currentUrl  The current URL in the browser.
     * @param expectedUrl The expected URL from the JSON file.
     * @param productName The name of the product.
     * @return boolean indicating whether the URLs match.
     */
    private boolean validateUrl(String currentUrl, String expectedUrl, String productName) {
        if (currentUrl.equals(expectedUrl)) {
            LOGGER.info("Product detail page for " + productName + " matches the expected URL.");
            AbstractComponents.logStep("TC[Product Detail Page Verification] : ✅Product detail page for " + productName + " matches the expected URL." );

            return true;
        } else {
            LOGGER.warning("URL mismatch for " + productName + ": Expected " + expectedUrl + " but got " + currentUrl);
            return false;
        }
    }
    
    /**
     * Verifies if all product details are visible.
     * @return boolean indicating whether all product details are visible.
     */
    public boolean checkProductDetailVisibility() {
        try {
            waitForWebElementAppear(productName);
            waitForWebElementAppear(productImage);
            waitForWebElementAppear(productDescription);
            waitForWebElementAppear(productPrice);
            AbstractComponents.logStep("TC[Product Detail Page Verification] : ✅Product details are diplayed." );

            return true;
        } catch (NoSuchElementException e) {
            LOGGER.warning("One or more product details are missing: " + e.getMessage());
            return false;
        }
    }

    /**
     * Verifies if the shopping badge is updated correctly after adding and removing a product.
     * @return boolean indicating whether the shopping badge updates correctly.
     */
    public boolean checkShoppingBadgeValue() {
        int badgeValue = getShoppingBadgeNumber();

        waitForWebElementAppear(removeButton);
        AbstractComponents.logStep("TC[Product Detail Page Verification] : ✅Remove button is displayed even when product is already on the cart." );
        removeButton.click();
        
        waitUntilBadgeUpdates(badgeValue - 1);
        AbstractComponents.logStep("TC[Product Detail Page Verification] : ✅Cart count updates when user clickes remove button" );

        int reduceBadgeValue = getShoppingBadgeNumber();
        if (reduceBadgeValue == badgeValue - 1) {
            addToCartButton.click();
            waitUntilBadgeUpdates(badgeValue);

            int addBadgeValue = getShoppingBadgeNumber();
            AbstractComponents.logStep("TC[Product Detail Page Verification] : ✅Cart count updates when user clickes add to cart button" );

            return addBadgeValue == badgeValue;
        }
        return false;
    }

    /**
     * Waits for the shopping badge value to update.
     * @param expectedValue The expected value of the shopping badge.
     */
    private void waitUntilBadgeUpdates(int expectedValue) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(driver -> getShoppingBadgeNumber() == expectedValue);
    }

    /**
     * Navigates back to the product listing page.
     */
    public void navigateBackToProductListing() {
        driver.navigate().back();
        LOGGER.info("Navigated back to the product listing page.");
    }
}
