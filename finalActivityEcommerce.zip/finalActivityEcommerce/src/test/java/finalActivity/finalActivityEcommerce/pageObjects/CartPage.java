package finalActivity.finalActivityEcommerce.pageObjects;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.fasterxml.jackson.databind.JsonNode;
import finalActivity.finalActivityEcommerce.abstractComponent.AbstractComponents;
import finalActivity.finalActivityEcommerce.data.DataConverter;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Page Object Model (POM) for CartPage, handling interactions with the cart in the e-commerce application.
 * This class provides methods for adding/removing items from the cart, verifying cart contents,
 * and interacting with cart UI elements.
 */
public class CartPage extends AbstractComponents {
    private WebDriver driver;
    private List<String> addedItems;
    private List<String> cartItems;

    /**
     * Constructor for CartPage class. Initializes the WebDriver and page elements.
     *
     * @param driver WebDriver instance to interact with the browser.
     */
    public CartPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        this.addedItems = new ArrayList<>();
        this.cartItems = new ArrayList<>();
        PageFactory.initElements(driver, this);
    }

    // Web elements on the Cart page
    @FindBy(id = "continue-shopping")
    private WebElement continueShoppingButton;

    @FindBy(id = "checkout")
    private WebElement checkoutButton;

    @FindBy(className = "cart_quantity")
    private WebElement cartQuantityLabel;

    @FindBy(className = "shopping_cart_badge")
    private WebElement shoppingCartBadge;

    @FindBy(className = "cart_item")
    private WebElement cartItem;

    /**
     * Adds a specified number of products to the cart based on the provided product limit.
     *
     * @param productLimit The maximum number of products to add to the cart.
     */
    public void addItemsToCart(int productLimit) {
        removeAllItemsFromCart(); // Clear the cart before adding new items
        addedItems.clear(); // Reset the added items tracking list

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JsonNode productData = DataConverter.getJsonData(); // Load product data from JSON

        if (productData == null || productData.isEmpty()) {
            System.err.println("Product JSON data is empty.");
            return;
        }

        int addedCount = 0;

        // Loop through the products and add to the cart until the limit is reached
        for (JsonNode product : productData) {
            int productId = product.get("id").asInt(); // Extract product ID
            if (productId >= productLimit) {
                continue; // Skip products beyond the limit
            }

            String productName = product.get("name").asText();
            System.out.println("Looking for product: " + productName + " (ID: " + productId + ")");

            try {
                // Locate the product element based on the product name
                WebElement productElement = driver.findElement(By.xpath("//div[contains(text(), '" + productName + "')]"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", productElement);

                // Locate and click the "Add to Cart" button
                WebElement addToCartButton = productElement.findElement(By.xpath("./ancestor::div[contains(@class, 'inventory_item')]//button[contains(text(), 'Add to cart')]"));
                addToCartButton.click();
                System.out.println("Added product: " + productName);

                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(), 'Remove')]")));
                addedItems.add(productName); // Track the added item

                addedCount++;
                if (addedCount == productLimit) {
                    break; // Stop once the required number of products are added
                }
            } catch (NoSuchElementException e) {
                System.err.println("Could not find product: " + productName);
            }
        }

        System.out.println("Total products added to cart: " + addedCount);
    }

    /**
     * Returns a list of added products to the cart.
     *
     * @return List of product names added to the cart.
     */
    public List<String> getAddedItems() {
        return new ArrayList<>(addedItems); // Return a copy to avoid modification
    }

    /**
     * Checks if the cart elements (buttons and labels) are visible on the Cart page.
     * Validates the URL to ensure we are on the correct page.
     *
     * @return true if cart elements are visible, false otherwise.
     * @throws IOException 
     */
    public boolean areCartElementsVisibleAndValidateURL() throws IOException {
        goToCartPage();
        try {
            if (checkCurrentURL(0)) {
                waitForWebElementAppear(continueShoppingButton);
                waitForWebElementAppear(checkoutButton);
                waitForWebElementAppear(cartQuantityLabel);
                System.out.println("Cart elements are visible.");
                AbstractComponents.logStep("TC[Cart Page Verification] : ✅ Cart page elements are displayed." );
                return true;
            }
        } catch (Exception e) {
            return false;
        }
        return false;
    }

    /**
     * Retrieves the items currently present in the cart.
     *
     * @return List of item names in the cart.
     */
    public List<String> getCartItems() {
        cartItems.clear();

        try {
            // Wait until cart items are visible
            waitForWebElementAppear(cartItem);
            List<WebElement> cartElements = driver.findElements(By.className("cart_item"));

            for (WebElement item : cartElements) {
                try {
                    WebElement nameElement = item.findElement(By.className("inventory_item_name"));
                    WebElement descElement = item.findElement(By.className("inventory_item_desc"));
                    WebElement priceElement = item.findElement(By.className("inventory_item_price"));

                    // Wait for the name, description, and price elements to appear
                    waitForWebElementAppear(nameElement);
                    waitForWebElementAppear(descElement);
                    waitForWebElementAppear(priceElement);

                    String name = nameElement.getText();
                    String description = descElement.getText();
                    String price = priceElement.getText();
                    AbstractComponents.logStep("TC[Cart Page Verification] : ✅ Cart product page details are displayed." );

                    if (!name.isEmpty() && !description.isEmpty() && !price.isEmpty()) {
                        cartItems.add(name);
                    }
                } catch (NoSuchElementException e) {
                    System.err.println("Missing product details in cart.");
                }
            }
        } catch (Exception e) {
            System.err.println("Error while retrieving cart items: " + e.getMessage());
        }

        return new ArrayList<>(cartItems); // Return a copy to avoid modification
    }

    /**
     * Verifies that the cart contains exactly the same products as the added items.
     *
     * @return true if the cart contents match the added items, false otherwise.
     */
    public boolean verifyCartContents() {
        List<String> cartItems = getCartItems();
        System.out.println("Cart Items: " + cartItems);
        return addedItems.equals(cartItems);
    }

    /**
     * Verifies if the shopping badge reflects the correct number of items in the cart after removing specified products.
     *
     * @param removeProductNumber The number of products to remove.
     * @return List of remaining cart items after removal.
     * @throws IOException If there is an issue during file processing.
     */
    public List<String> checkShoppingBadge(String removeProductNumber) throws IOException {
        int badgeNum = getShoppingBadgeNumber(); // Get initial badge number
        int removeNumber = Integer.parseInt(removeProductNumber); // Number of products to remove
        System.out.println("Removing " + removeNumber + " products...");

        // Remove the specified number of products
        removeSpecificNumberOfProducts(removeNumber);

        int newBadgeNumber = getShoppingBadgeNumber(); // Get new badge number after removal

        // Check if the badge number has decreased by the correct amount
        if (badgeNum - newBadgeNumber == removeNumber) {
            AbstractComponents.logStep("TC[Cart Page Verification] : ✅ Items in the cart successfully updates." );
            List<String> remainingItems = getRemainingCartItems();
            continueShoppingButton.click();  // Click the continue shopping button
            if (checkCurrentURL(3)) {
                AbstractComponents.logStep("TC[Cart Page Verification] : ✅ System redirects to product listing page after clicking 'Continue Shopping'." );
                return remainingItems;
            }
        }
        return new ArrayList<>();
    }

    /**
     * Verifies if the cart items persist after a user logs out and logs back in.
     *
     * @param removeProductNumber The number of products to remove during the test.
     * @return true if cart items persist, false otherwise.
     * @throws IOException If there is an error reading the data.
     * @throws InterruptedException If the thread is interrupted.
     */
    public boolean checkItemPersistenceAfterLogin(String removeProductNumber) throws IOException, InterruptedException {
        List<String> initialCartItems = checkShoppingBadge(removeProductNumber);
        clickLogOut();
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginAccount();
        goToCartPage();
        List<String> newCartItems = getCartItems();
        
        return initialCartItems.equals(newCartItems);
    }

    /**
     * Retrieves a list of remaining items in the cart.
     *
     * @return List of remaining item names in the cart.
     */
    private List<String> getRemainingCartItems() {
        List<String> remainingItems = new ArrayList<>();

        // Get all the cart item elements
        List<WebElement> cartItems = driver.findElements(By.xpath("//div[@class='cart_item']"));

        for (WebElement item : cartItems) {
            String itemName = item.findElement(By.xpath(".//div[@class='inventory_item_name']")).getText();
            remainingItems.add(itemName);
        }

        return remainingItems;
    }

    /**
     * Removes a specific number of products from the cart.
     *
     * @param numberOfProductsToRemove The number of products to remove.
     */
    private void removeSpecificNumberOfProducts(int numberOfProductsToRemove) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        List<WebElement> removeButtons = driver.findElements(By.xpath("//button[contains(text(), 'Remove')]"));

        while (numberOfProductsToRemove > 0 && !removeButtons.isEmpty()) {
            WebElement removeButton = removeButtons.get(0);
            try {
                removeButton.click();
                System.out.println("Removed product.");
                // Wait for the cart to update and refresh the removeButtons list
                wait.until(ExpectedConditions.stalenessOf(removeButton));
                removeButtons = driver.findElements(By.xpath("//button[contains(text(), 'Remove')]"));
                numberOfProductsToRemove--;
            } catch (StaleElementReferenceException e) {
                // The element is no longer attached to the DOM; refresh the list
                removeButtons = driver.findElements(By.xpath("//button[contains(text(), 'Remove')]"));
            }
        }

        if (numberOfProductsToRemove > 0) {
            System.err.println("Not enough products to remove. Cart may be empty.");
        }
    }

    /**
     * Removes all items from the cart.
     */
    private void removeAllItemsFromCart() {
        List<WebElement> removeButtons = driver.findElements(By.xpath("//button[contains(text(), 'Remove')]"));
        for (WebElement removeButton : removeButtons) {
            removeButton.click();
        }
    }
}
