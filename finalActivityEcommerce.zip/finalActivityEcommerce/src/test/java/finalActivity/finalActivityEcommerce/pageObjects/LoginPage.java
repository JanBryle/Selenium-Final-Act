package finalActivity.finalActivityEcommerce.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.fasterxml.jackson.databind.JsonNode;

import finalActivity.finalActivityEcommerce.abstractComponent.AbstractComponents;
import finalActivity.finalActivityEcommerce.data.DataConverter;

import java.io.IOException;

/**
 * Represents the Login Page of the e-commerce application.
 * This class encapsulates the web elements and actions related to the login functionality.
 * It includes fields for username, password, login button, and error message.
 */
public class LoginPage extends AbstractComponents {

    private WebDriver driver;

    // Web elements for the login page
    @FindBy(id = "user-name")
    private WebElement usernameField;

    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(xpath = "//h3[@data-test='error']")
    private WebElement errorMessageLabel;

    @FindBy(id = "login-button")
    private WebElement loginButton;

    /**
     * Constructs a LoginPage object using the provided WebDriver instance.
     * This constructor initializes the web elements on the login page using the PageFactory.
     *
     * @param driver The WebDriver instance used for interacting with the browser.
     */
    public LoginPage(WebDriver driver) {
        super(driver);  // Initialize the parent class (AbstractComponents)
        this.driver = driver;
        PageFactory.initElements(driver, this);  // Initialize web elements using PageFactory
    }

    /**
     * Navigates to the login page URL.
     * This method is the prerequisite for performing any login actions.
     * 
     * Prerequisite:
     * - The WebDriver instance must be initialized and properly set up.
     * 
     * @throws IOException If an I/O exception occurs while loading the page.
     */
    public void goTo() throws IOException {
        driver.get("https://www.saucedemo.com/");  // Navigate to the login page URL
    }

    /**
     * Logs in to the application using the provided credentials.
     * This method performs the following steps:
     * 1. Navigates to the login page.
     * 2. Enters the username and password into their respective fields.
     * 3. Clicks the login button.
     * 4. Returns a ProductListPage object if login is successful.
     * 
     * Prerequisites:
     * - Valid username and password must be provided.
     * - The login page must be accessible.
     * 
     * @param username The username for login.
     * @param password The password for login.
     * @return An instance of ProductListPage if login is successful.
     * @throws IOException If an I/O exception occurs while navigating to the page.
     * @throws InterruptedException If the thread is interrupted while waiting for elements.
     */
    public ProductListPage loginApplication(String username, String password) throws IOException, InterruptedException {
        goTo();  // Navigate to the login page
        System.out.println("Attempting login with username: " + username);

        // Enter the username and password into respective fields
        usernameField.sendKeys(username);
        passwordField.sendKeys(password);

        // Click the login button to submit the login form
        loginButton.click();

        // Return the ProductListPage object after successful login
        return new ProductListPage(driver);
    }

    /**
     * Retrieves the error message displayed after a failed login attempt.
     * This method waits for the error message element to appear and then retrieves its text.
     * 
     * Prerequisites:
     * - Ensure a login attempt has been made with invalid credentials.
     * 
     * Steps:
     * 1. Wait for the error message element to appear.
     * 2. Retrieve and return the text of the error message.
     * 
     * @return The error message displayed after a failed login attempt.
     * @throws IOException If an I/O exception occurs while navigating to the page.
     * @throws InterruptedException If the thread is interrupted while waiting.
     */
    public String getErrorMessageAfterAttempt() throws IOException, InterruptedException {
        // Wait for the error message element to appear on the page
        waitForWebElementAppear(errorMessageLabel);

        // Log and return the error message text
        String errorMessage = errorMessageLabel.getText();
        System.out.println("Error message: " + errorMessage);
        return errorMessage;
    }

    /**
     * Performs login and checks the visibility of login page elements (username, password, and login button).
     * This method ensures that all required elements are visible before attempting login.
     * 
     * Prerequisites:
     * - The login page must be loaded.
     * 
     * Steps:
     * 1. Check if all login page elements are visible (username, password fields, and login button).
     * 2. If all elements are visible, proceed to login.
     * 3. Return the ProductListPage object upon successful login.
     * 
     * @param username The username for login.
     * @param password The password for login.
     * @return An instance of ProductListPage after successful login, or null if elements are not visible.
     * @throws IOException If an I/O exception occurs while navigating to the page.
     * @throws InterruptedException If the thread is interrupted while waiting for elements.
     */
    public ProductListPage loginAndCheckElementVisibility() throws IOException, InterruptedException {
        // Check the visibility of all login page elements
        if (checkLoginPageElementVisibility()) {
            // Attempt login if elements are visible
            loginAccount();
            logStep("User was able to successfully login");
            return new ProductListPage(driver);  // Return the next page object after successful login
        }
        return null;  // Return null if elements are not visible
    }

    /**
     * Checks if the login page elements (username, password fields, and login button) are visible.
     * This method ensures the necessary elements are loaded before proceeding with any actions.
     * 
     * Prerequisites:
     * - The login page must be loaded.
     * 
     * Steps:
     * 1. Wait for the username field, password field, and login button to be visible on the page.
     * 2. Return true if all elements are visible, false otherwise.
     * 
     * @return true if all login page elements are visible; false otherwise.
     */
    public boolean checkLoginPageElementVisibility() {
        // Wait for each element to be visible on the page
        waitForWebElementAppear(usernameField);
        waitForWebElementAppear(passwordField);
        waitForWebElementAppear(loginButton);
        logStep("✅ TC[Login Page Verification] : User was able  access login page and fields are displayed. ");
        return true;  // Return true if all elements are visible
    }
    
    public void loginAccount() throws IOException, InterruptedException {
        String filePath = "loginData.json";
		JsonNode firstData = DataConverter.getFirstJsonObject(filePath);
        String email = (firstData != null) ? firstData.get("email").asText() : "";
        String password = (firstData != null) ? firstData.get("password").asText() : "";
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginApplication(email, password);
    }
}
