package finalActivity.finalActivityEcommerce.pageObjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import finalActivity.finalActivityEcommerce.abstractComponent.AbstractComponents;

/**
 * This class represents the Order Completion Page in the E-Commerce application.
 * It provides methods for interacting with elements such as completing the order, 
 * verifying successful order placement, and navigating back to the product page.
 */
public class OrderCompletion extends AbstractComponents {

    private WebDriver driver;

    @FindBy(id = "finish")
    private WebElement finishBtn;

    @FindBy(xpath = "//h2[@class = 'complete-header']")
    private WebElement thankYouMessage;

    @FindBy(id = "back-to-products")
    private WebElement backHomeBtn;

    @FindBy(id = "checkout")
    private WebElement checkoutButton;

    @FindBy(id = "first-name")
    private WebElement firstNameElement;

    @FindBy(id = "last-name")
    private WebElement lastNameElement;

    @FindBy(id = "postal-code")
    private WebElement postalCodeElement;

    @FindBy(id = "continue")
    private WebElement continueButton;

    /**
     * Constructor to initialize the OrderCompletion page object.
     * 
     * @param driver WebDriver instance to interact with the browser.
     */
    public OrderCompletion(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * Completes the order process by checking out and verifying the success message.
     * After completing the order, it navigates back to the product page.
     * 
     * @return true if the order is successfully completed and navigates back to the products page, false otherwise.
     * @throws IOException If there is an error during the operation.
     * @throws InterruptedException If the thread is interrupted.
     */
    public boolean proceedPage() throws IOException, InterruptedException {
        InformationPage informationPage = new InformationPage(driver);
        
        // Proceed to the success checkout page and click finish
        informationPage.successCheckOutPage();
        finishBtn.click();
        AbstractComponents.logStep("TC[Order Completion Verification] : ✅ System redirects user to checkout complete page after clicking finish button");

        // Verify visibility of success elements and navigate back to home
        if (elementVisibility()) {
        	System.out.println(3);        	
            backHomeBtn.click();
            AbstractComponents.logStep("TC[Order Completion Verification] : ✅ System redirects user to the prodict listing after clicking back home button.");

            // Check if the current URL is the product page URL
            return checkCurrentURL(3);  // 3 refers to the URL of the product page
        } else {
            return false;
        }
    }

    /**
     * Verifies the visibility of success elements on the order completion page 
     * and ensures that the page has loaded successfully.
     * 
     * @return true if both the success message and the back home button are visible, false otherwise.
     */
    public boolean elementVisibility() {
        try {
        	System.out.println(driver.getCurrentUrl());
        	System.out.println(checkCurrentURL(2));
            if (checkCurrentURL(2)) {  // 2 refers to the URL of the order completion page
            	System.out.println("a3");
            	waitForWebElementAppear(thankYouMessage);
                waitForWebElementAppear(backHomeBtn);
                AbstractComponents.logStep("TC[Order Completion Verification] : ✅ Webelements are displayed in order completion page.");
                return true;
            }
        } catch (Exception e) {
            System.err.println("Error during element visibility check: " + e.getMessage());
        }
        return false;
    }}