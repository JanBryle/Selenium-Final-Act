package finalActivity.finalActivityEcommerce.pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import finalActivity.finalActivityEcommerce.abstractComponent.AbstractComponents;

public class CheckoutOverview extends AbstractComponents {

    WebDriver driver;

    /**
     * Constructor to initialize the CheckoutOverview page and WebElements.
     * @param driver The WebDriver instance used for interacting with the browser.
     */
    public CheckoutOverview(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // WebElements for interacting with the checkout page
    @FindBy(id = "checkout")
    WebElement checkoutButton;

    @FindBy(id = "first-name")
    WebElement firstNameElement;

    @FindBy(id = "last-name")
    WebElement lastNameElement;

    @FindBy(id = "postal-code")
    WebElement postalCodeElement;

    @FindBy(id = "cancel")
    WebElement cancelButton;

    @FindBy(id = "finish")
    WebElement finishButton;

    @FindBy(id = "continue")
    WebElement continueButton;

    @FindBy(xpath = "//h3")
    WebElement errorMessageElement;

    @FindBy(xpath = "//div[@class = 'cart_item_label']")
    List<WebElement> cartItems;

    @FindBy(xpath = "//div[@data-test='payment-info-value']")
    WebElement paymentInfo;

    @FindBy(xpath = "//div[@data-test='shipping-info-value']")
    WebElement shippingInfo;

    @FindBy(xpath = "//div[@data-test='subtotal-label']")
    WebElement subTotal;

    @FindBy(xpath = "//div[@data-test='tax-label']")
    WebElement taxLabel;

    @FindBy(xpath = "//div[@data-test='total-label']")
    WebElement totalLabel;

    /**
     * Verifies that all items in the cart are displayed on the checkout overview page.
     * @param cartItems List of item names to verify on the checkout page.
     * @return true if all items are displayed, false otherwise.
     */
    private boolean verifyCartItemsOnCheckoutPage(List<String> cartItems) {
        boolean allItemsFound = true;

        // Loop through each item in the cart and check if it's visible on the checkout page
        for (String cartItem : cartItems) {
            boolean itemFound = false;

            for (WebElement cartItemElement : this.cartItems) {
                if (cartItemElement.getText().contains(cartItem)) {
                    itemFound = true;
                    break;  // Exit early if the item is found
                }
            }

            if (!itemFound) {
                allItemsFound = false;
                break;  // Exit early if any item is missing
            }
        }
        return allItemsFound;
    }
    
    /**
     * Extracts the numerical value from a currency-formatted string (e.g., "$10.00").
     * @param text The string containing the currency amount (e.g., "$10.00").
     * @return double The extracted numerical amount.
     */
    private double extractAmountFromText(String text) {
        String amountText = text.split("\\$")[1];  // Split the string at '$' and get the numeric part
        return Double.parseDouble(amountText.replace(",", ""));  // Remove commas and convert to double
    }

    /**
     * Handles the main checkout overview process, from verifying cart items to checking totals.
     * @param firstName The user's first name for the checkout form.
     * @param lastName The user's last name for the checkout form.
     * @param postalCode The user's postal code for the checkout form.
     * @param errorMessage The expected error message (if any) during the process.
     * @return true if the checkout process completes successfully, false otherwise.
     * @throws IOException If an error occurs during the process.
     * @throws InterruptedException If the thread is interrupted during the process.
     */
    public boolean checkOutOverviewPage() throws IOException, InterruptedException {
    	  
        
        // Create a CartPage instance to retrieve cart items
       // Navigate to the cart page
         // Click the checkout button

        // Fill in the checkout form with user details
        InformationPage informationPage = new InformationPage(driver);
        List<String> cartItems = informationPage.successCheckOutPage();
        // Click the continue button to proceed

        if(checkCurrentURL(4)) {
        // Extract and validate the subtotal, tax, and total values
        double itemTotal = extractAmountFromText(subTotal.getText());
        double taxTotal = extractAmountFromText(taxLabel.getText());
        double finalTotal = extractAmountFromText(totalLabel.getText());

        // Check if itemTotal + taxTotal equals the finalTotal
        if (itemTotal + taxTotal == finalTotal) {
            System.out.println("Subtotal, tax, and total amounts are correct.");
            AbstractComponents.logStep("TC[Checkout Overview Verification] : Product price calculation is correct.");

        } else {
            System.out.println("The totals do not match! Subtotal + Tax does not equal Final Total.");
            return false;  // Return false if the totals don't match
        }

        // Verify that the necessary elements are visible on the page
        if (checkOutOverviewVisibility()) {
            cancelButton.click();  // Cancel the checkout process
            AbstractComponents.logStep("TC[Checkout Overview Verification] : Clicking cancel button redirects user to product listing page.");
            goToCartPage();  // Go back to the cart page
            
            // Verify that all cart items are visible on the checkout overview page
            if (verifyCartItemsOnCheckoutPage(cartItems)) {
                AbstractComponents.logStep("TC[Checkout Overview Verification] : All cart items are correctly displayed on the checkout overview page.");
            } else {
                System.out.println("Some cart items are missing on the checkout overview page.");
                return false;
            }

            // Proceed with the checkout again
            checkoutButton.click();
            informationPage.fillOutData();

            return true;  // Return true if everything is correct
        }}
        return false;  // Return false if the checkout overview elements are not visible
    }

    /**
     * Checks if all necessary elements are visible on the checkout overview page.
     * @return true if all elements are visible, false otherwise.
     */
    private boolean checkOutOverviewVisibility() {
        try {
            // Wait for visibility of key elements on the page
            waitForWebElementsAppear(cartItems);
            waitForWebElementAppear(paymentInfo);
            waitForWebElementAppear(shippingInfo);
            waitForWebElementAppear(subTotal);
            waitForWebElementAppear(taxLabel);
            waitForWebElementAppear(totalLabel);
            waitForWebElementAppear(cancelButton);
            waitForWebElementAppear(finishButton);
            AbstractComponents.logStep("TC[Checkout Overview Verification] : Checkout overview elements are displayed.");
            return true;
        } catch (Exception e) {
            return false;  // Return false if any element is not visible
        }
    }

    
}
