package finalActivity.finalActivityEcommerce.pageObjects;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import finalActivity.finalActivityEcommerce.abstractComponent.AbstractComponents;

/**
 * Represents the Product List Page of the e-commerce application.
 * This class encapsulates the web elements and actions related to the product list functionality.
 */
public class ProductListPage extends AbstractComponents {

    private WebDriver driver;

    @FindBy(className = "inventory_item_name")
    private List<WebElement> productNames;

    @FindBy(xpath = "//div[@class='inventory_item_img']//img")
    private List<WebElement> productImages;

    @FindBy(className = "inventory_item_desc")
    private List<WebElement> productDescriptions;

    @FindBy(className = "inventory_item_price")
    private List<WebElement> productPrices;

    @FindBy(xpath = "//button[contains(text(), 'Add to cart')]")
    private List<WebElement> addToCartButtons;

    @FindBy(className = "product_sort_container")
    private WebElement sortButton;
    /**
     * Constructs a ProductListPage object with the provided WebDriver.
     *
     * @param driver The WebDriver instance used for interacting with the browser.
     */
    public ProductListPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * Retrieves the number of product names displayed on the product list page,
     * after waiting for their visibility.
     *
     * @return The number of product names found.
     */
    public int getProductNameCount() {
        productNames.forEach(this::waitForWebElementAppear);
        return productNames.size();
    }

    /**
     * Retrieves the number of product images displayed on the product list page,
     * after waiting for their visibility.
     *
     * @return The number of product images found.
     */
    public int getProductImageCount() {
        productImages.forEach(this::waitForWebElementAppear);
        return productImages.size();
    }

    /**
     * Retrieves the number of product descriptions displayed on the product list page,
     * after waiting for their visibility.
     *
     * @return The number of product descriptions found.
     */
    public int getProductDescriptionCount() {
        productDescriptions.forEach(this::waitForWebElementAppear);
        return productDescriptions.size();
    }

    /**
     * Retrieves the number of product prices displayed on the product list page,
     * after waiting for their visibility.
     *
     * @return The number of product prices found.
     */
    public int getProductPriceCount() {
        productPrices.forEach(this::waitForWebElementAppear);
        return productPrices.size();
    }

    /**
     * Retrieves the number of "Add to cart" buttons displayed on the product list
     * page, after waiting for their visibility.
     *
     * @return The number of "Add to cart" buttons found.
     */
    public int getAddToCartButtonCount() {
        addToCartButtons.forEach(this::waitForWebElementAppear);
        return addToCartButtons.size();
    }

    /**
     * Clicks each "Add to cart" button, checks if the text changes to "Remove",
     * and clicks "Remove" if it does. Uses streams and Actions.
     *
     * @return true if all buttons changed to "Remove" and then back to "Add to cart",
     * false otherwise.
     * @throws InterruptedException
     */
 
    public boolean checkButtonTextChanging() throws InterruptedException {
        boolean allButtonsChanged = true;

        while (true) {
            List<WebElement> addButtons = driver.findElements(By.xpath("//button[contains(text(), 'Add to cart')]"));
            
            if (addButtons.isEmpty()) break; // Exit loop when no "Add to cart" buttons left

            for (int i = 0; i < addButtons.size(); i++) {
                // Re-fetch the element to avoid stale reference
                List<WebElement> updatedAddButtons = driver.findElements(By.xpath("//button[contains(text(), 'Add to cart')]"));
                if (i >= updatedAddButtons.size()) break; // Safety check in case of re-rendering

                WebElement addButton = updatedAddButtons.get(i);
                waitForWebElementAppear(addButton);
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", addButton);
                addButton.click();
                System.out.println("Clicked Add to cart button");

                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
                wait.until(ExpectedConditions.invisibilityOf(addButton)); // Wait for the button to disappear
            }
        }

        // Now click "Remove" buttons
        while (true) {
            List<WebElement> removeButtons = driver.findElements(By.xpath("//button[contains(text(), 'Remove')]"));

            if (removeButtons.isEmpty()) break; // Exit when no "Remove" buttons left

            for (int i = 0; i < removeButtons.size(); i++) {
                // Re-fetch the element to avoid stale reference
                List<WebElement> updatedRemoveButtons = driver.findElements(By.xpath("//button[contains(text(), 'Remove')]"));
                if (i >= updatedRemoveButtons.size()) break; // Safety check in case of re-rendering

                WebElement removeButton = updatedRemoveButtons.get(i);
                waitForWebElementAppear(removeButton);
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", removeButton);
                removeButton.click();
                System.out.println("Clicked Remove button");

                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
                wait.until(ExpectedConditions.invisibilityOf(removeButton)); // Wait for the button to disappear
            }
        }

        return allButtonsChanged;
    }
    public boolean checkOrder(String sortingMethod) throws IOException {
        /**
         * Verifies whether the product list is correctly sorted based on the specified sorting method.
         * 
         * @param sortingMethod The sorting method to verify (e.g., "Name (A to Z)", "Price (low to high)", 
         *                      "Price (high to low)", "Name (Z to A)"). This method checks the current 
         *                      sorting state of the product list against the provided sorting criterion.
         * 
         * @return boolean Returns true if the products are correctly sorted according to the sorting method, 
         *                 false otherwise.
         */

        // Capture the initial order of product names before applying sorting
        List<String> initialOrder = productNames.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());

        // Select the sorting option based on the input sorting method
        Select dropdown = new Select(sortButton);
        int selectedIndex = 0; // Default to the first option, which is "Name (A to Z)"

        // Map the sorting method string to the corresponding dropdown index
        if (sortingMethod.contains("Name (A to Z)")) {
            selectedIndex = 0;
        } else if (sortingMethod.contains("Name (Z to A)")) {
            selectedIndex = 1;
        } else if (sortingMethod.contains("Price (low to high)")) {
            selectedIndex = 2;
        } else if (sortingMethod.contains("Price (high to low)")) {
            selectedIndex = 3;
        }
        dropdown.selectByIndex(selectedIndex);

        // Wait for the DOM to update after sorting, ensuring the sorting effect is applied
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.textToBePresentInElement(productNames.get(0), productNames.get(0).getText()));

        // Capture the new order of product names after sorting
        List<String> sortedOrder = productNames.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());

        boolean isSortedCorrectly = false;

        // If sorting by Name (A to Z)
        if (sortingMethod.contains("Name (A to Z)")) {
            List<String> expectedOrder = new ArrayList<>(initialOrder);
            Collections.sort(expectedOrder);
            isSortedCorrectly = IntStream.range(0, sortedOrder.size())
                    .allMatch(i -> sortedOrder.get(i).equals(expectedOrder.get(i)));
        } 
        // If sorting by Name (Z to A)
        else if (sortingMethod.contains("Name (Z to A)")) {
            List<String> expectedOrder = new ArrayList<>(initialOrder);
            expectedOrder.sort(Collections.reverseOrder());
            isSortedCorrectly = IntStream.range(0, sortedOrder.size())
                    .allMatch(i -> sortedOrder.get(i).equals(expectedOrder.get(i)));
        } 
        // If sorting by Price (low to high) or Price (high to low)
        else if (sortingMethod.contains("Price (low to high)") || sortingMethod.contains("Price (high to low)")) {
            // Parse the prices as double values for sorting comparison
            List<Double> initialPrices = productPrices.stream()
                    .map(priceElement -> Double.parseDouble(priceElement.getText().replace("$", "")))
                    .collect(Collectors.toList());

            List<Double> sortedPrices = productPrices.stream()
                    .map(priceElement -> Double.parseDouble(priceElement.getText().replace("$", "")))
                    .collect(Collectors.toList());

            List<Double> expectedPrices = new ArrayList<>(initialPrices);

            // Sort prices based on the chosen sorting method
            if (sortingMethod.contains("Price (low to high)")) {
                Collections.sort(expectedPrices);
            } else {
                expectedPrices.sort(Collections.reverseOrder());
            }

            // Compare the sorted price lists
            isSortedCorrectly = IntStream.range(0, sortedPrices.size())
                    .allMatch(i -> sortedPrices.get(i).equals(expectedPrices.get(i)));
        }

        return isSortedCorrectly;
    }

    

}