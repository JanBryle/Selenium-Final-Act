package finalActivity.finalActivityEcommerce.abstractComponent;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * AbstractComponents class provides common reusable utility methods for web page interaction
 * using Selenium WebDriver, such as element visibility checks, navigation actions,
 * and login handling.
 */
public class AbstractComponents {

    protected WebDriver driver;

    // Web Elements
    @FindBy(id = "shopping_cart_container")
    private WebElement shoppingCart;

    @FindBy(id = "logout_sidebar_link")
    private WebElement logoutLink;

    @FindBy(id = "react-burger-menu-btn")
    private WebElement burgerMenu;

    @FindBy(id = "react-burger-cross-btn")
    private WebElement burgerMenuExit;

    @FindBy(className = "shopping_cart_badge")
    private WebElement shoppingBadge;
    
    /**
     * Constructor to initialize AbstractComponents with WebDriver.
     * 
     * @param driver The WebDriver instance passed from the test or page class
     */
    public AbstractComponents(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * Waits until the specified WebElement becomes visible on the page.
     *
     * @param element The WebElement to wait for
     */
    public void waitForWebElementAppear(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    /**
     * Waits until the specified WebElement disappears from the page.
     *
     * @param element The WebElement to wait for disappearance
     */
    public void waitForWebElementDisappear(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.invisibilityOf(element));
    }

    /**
     * Waits for each WebElement in a list to become visible.
     *
     * @param elements List of WebElements to wait for
     */
    public void waitForWebElementsAppear(List<WebElement> elements) {
        for (WebElement element : elements) {
            waitForWebElementAppear(element);
        }
    }

    /**
     * Waits until the given WebElement displays the expected text.
     *
     * @param element      The WebElement to monitor
     * @param expectedText The expected text content
     */
    public void waitForElementTextToBe(WebElement element, String expectedText) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.textToBePresentInElement(element, expectedText));
    }

    /**
     * Returns the current URL of the browser.
     *
     * @return The current page URL
     */
    public String getCurrentURL() {
        return driver.getCurrentUrl();
    }

    /**
     * Retrieves the number displayed in the shopping cart badge.
     *
     * @param shoppingBadge The badge WebElement
     * @return The item count as an integer, or 0 if not displayed
     */
    public int getShoppingBadgeNumber() {
        if (isElementPresent(shoppingBadge)) {
            return Integer.parseInt(shoppingBadge.getText());
        }
        return 0;
    }

    /**
     * Checks if a WebElement is present and visible on the DOM.
     *
     * @param element The WebElement to check
     * @return true if element is visible, false otherwise
     */
    public boolean isElementPresent(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Clicks the shopping cart icon to navigate to the cart page.
     */
    public void goToCartPage() {
        shoppingCart.click();
    }

    /**
     * Opens the burger menu (side navigation).
     */
    public void openBurgerMenu() {
        burgerMenu.click();
    }

    /**
     * Closes the burger menu.
     */
    public void closeBurgerMenu() {
        burgerMenuExit.click();
    }

    /**
     * Opens the burger menu and clicks the logout link.
     */
    public void clickLogOut() {
        openBurgerMenu();
        logoutLink.click();
    }

       

	public boolean checkCurrentURL(int URLIndex) throws IOException {
		   ObjectMapper objectMapper = new ObjectMapper();
	        // Read the JSON file into a JsonNode
	        File jsonFile = new File("url.json"); // change path as needed
	        
	        JsonNode rootArray = objectMapper.readTree(jsonFile);
			   System.out.println("ds");

	        // Access item by index
	        JsonNode url = rootArray.get(URLIndex); // Get second item (index 1)

	        String storedURL = url.get("url").asText();
	        System.out.println(storedURL);
	        System.out.println(driver.getCurrentUrl());
	        if(driver.getCurrentUrl().contains(storedURL)) {
	        	return true;
	        }else {
	        	return false;
	        }
}
	
	public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_GREEN = "\u001B[32m";

    public static void logStep(String message) {
        System.out.println(ANSI_GREEN + "[INFO] - " + message + ANSI_RESET);
    }

}