package finalActivity.finalActivityEcommerce.testing;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import finalActivity.finalActivityEcommerce.abstractComponent.AbstractComponents;
import finalActivity.finalActivityEcommerce.data.ExcelData;
import finalActivity.finalActivityEcommerce.pageObjects.InformationPage;
import finalActivity.finalActivityEcommerce.pageObjects.LoginPage;
import finalActivity.finalActivityEcommerce.testComponents.BaseTest;

/**
 * This class is responsible for testing negative scenarios such as:
 * - Invalid login attempts
 * - Invalid form submissions during the checkout process
 *
 * Business Rule Document (BRD) references:
 * - Login Page Verification: BRD 2 to 6, 8
 * - Checkout Process Verification: BRD 4 to 10
 */
public class ErrorValidation extends BaseTest {

    /**
     * Negative Test: Login Page Error Validation
     *TC [Login Page Verification] : 2-6 & 8
     * Pre-requisite:
     * - User already has access to the Login Page
     *
     * Test Steps:
     * 1. Enter user email
     * 2. Enter user password
     * 3. Click login button
     * 4. Verify that the correct error message is displayed
     *
     * @param email                The email input
     * @param password             The password input
     * @param expectedErrorMessage The expected login error message
     * @param expectedURL          The expected URL to verify the page didn't redirect
     * @throws IOException If login interaction fails
     */
    @Test(dataProvider = "loginNegativeData", dataProviderClass = ExcelData.class)
    @Parameters({ "email", "password", "expectedErrorMessage", "expectedURL" })
    public void errorLogin(String username, String password, String expectedErrorMessage, String expectedURL)
            throws IOException {
        try {
            LoginPage loginPage = new LoginPage(driver);
            loginPage.loginApplication(username, password);

            String actualErrorMessage = loginPage.getErrorMessageAfterAttempt();
            SoftAssert softAssert = new SoftAssert();

            softAssert.assertTrue(actualErrorMessage.contains(expectedErrorMessage),
                    "❌ Mismatch in error message.\nExpected: [" + expectedErrorMessage + "]\nActual: [" + actualErrorMessage + "]");
            softAssert.assertAll();

            Assert.assertTrue(driver.getCurrentUrl().contains(expectedURL),
                    "❌ URL did not remain on the login page as expected.");
            AbstractComponents.logStep("TC[Login Page Verification] : ✅ Login URL matches the expected URL");
            AbstractComponents.logStep("TC[Login Page Verification] : ✅ Login error validation passed");
        } catch (Exception e) {
            System.err.println("❌ Login test failed for Email: " + username + " due to exception: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Test failed due to unexpected exception.");
        }
    }

    /**
     * Negative Test: Checkout Information Page Error Validation
     * TC[Checkout Process Verification] : 4-10 
     * Pre-requisite:
     * - User is already logged in
     * - Items are added to the cart
     * - Checkout button has been clicked
     *
     * Test Steps:
     * 1. Enter First Name
     * 2. Enter Last Name
     * 3. Enter Postal Code
     * 4. Click Continue button
     * 5. Verify the correct error message is displayed
     *
     * @param firstName    The first name input
     * @param lastName     The last name input
     * @param postalCode   The postal code input
     * @param errorMessage The expected error message
     * @throws IOException           If interaction fails
     * @throws InterruptedException If thread sleep is interrupted
     */
    @Test(dataProvider = "productInformationPageErrorValidation", dataProviderClass = ExcelData.class)
    @Parameters({ "firstName", "lastName", "postalCode", "errorMessage" })
    public void checkInformationPageError(String firstName, String lastName, String postalCode, String errorMessage)
            throws IOException, InterruptedException {
        try {
            InformationPage informationPage = new InformationPage(driver);
            boolean result = informationPage.errorCheckOutPage(firstName, lastName, postalCode, errorMessage);
            
            AbstractComponents.logStep("TC[Checkout Process Verification] : ✅ Checkout error validation passed | Input: " + firstName + " " + lastName);
            Assert.assertTrue(result, "❌ Checkout page validation failed.");

        } catch (Exception e) {
            System.err.println("❌ Checkout info test failed for: " + firstName + " " + lastName + " | Exception: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Test failed due to unexpected exception.");
        }
    }
}
