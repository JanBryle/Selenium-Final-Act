package finalActivity.finalActivityEcommerce.testing;

import java.io.IOException;
import java.util.logging.Logger;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.JsonNode;

import finalActivity.finalActivityEcommerce.abstractComponent.AbstractComponents;
import finalActivity.finalActivityEcommerce.data.DataConverter;
import finalActivity.finalActivityEcommerce.data.ExcelData;
import finalActivity.finalActivityEcommerce.pageObjects.AddToCart;
import finalActivity.finalActivityEcommerce.pageObjects.CartPage;
import finalActivity.finalActivityEcommerce.pageObjects.CheckoutOverview;
import finalActivity.finalActivityEcommerce.pageObjects.InformationPage;
import finalActivity.finalActivityEcommerce.pageObjects.LoginPage;
import finalActivity.finalActivityEcommerce.pageObjects.ProductDetailPage;
import finalActivity.finalActivityEcommerce.pageObjects.ProductListPage;
import finalActivity.finalActivityEcommerce.testComponents.BaseTest;

/**
 * This test class includes the scenarios for verifying the product
 * functionality and the Add to Cart button functionality on the Product Listing
 * Page. These tests ensure that the product sorting, button functionality, and
 * UI elements are working as expected.
 * 
 * Pre-requisites: - The URL JSON file (`url.json`) should be available and
 * correctly formatted. - The test environment should be set up with valid
 * credentials and access to the product list.
 */
public class WorkArounds extends BaseTest {

	private static final Logger LOGGER = Logger.getLogger(WorkArounds.class.getName());

	/**
	 * Test Case: Verify Product Sorting Functionality
	 *TC[Product Listing Page Verification] : 5-8
	 * <p>
	 * <b>Pre-requisites:</b>
	 * <ul>
	 * <li>User must be able to log in using valid credentials.</li>
	 * <li>Product list must be accessible after login.</li>
	 * <li>Sorting methods must be available on the product list page.</li>
	 * </ul>
	 *
	 * <p>
	 * <b>Test Data:</b> Supplied by ExcelData.class via @DataProvider:
	 * <ul>
	 * <li><b>sortingMethod</b>: The sorting strategy to be applied (e.g., Name (A
	 * to Z), Price (low to high)).</li>
	 * </ul>
	 *
	 * <p>
	 * <b>Test Steps:</b>
	 * <ol>
	 * <li>Log in with valid credentials.</li>
	 * <li>Navigate to the product list page.</li>
	 * <li>Apply the specified sorting method.</li>
	 * <li>Verify that the products are sorted according to the given method.</li>
	 * </ol>
	 *
	 * <p>
	 * <b>Expected Result:</b>
	 * <ul>
	 * <li>Products should appear in the correct order based on the selected sorting
	 * method.</li>
	 * <li>No exceptions or UI errors should occur during the process.</li>
	 * </ul>
	 *
	 * @param sortingMethod The sorting method to apply, provided by the Excel data
	 *                      source.
	 */

	@Test(dataProvider = "productListDataOrder", dataProviderClass = ExcelData.class)
	public void verifyProductSorting(String sortingMethod) {
		try {
			// Step 1: Log in and navigate to the product list page
			LoginPage loginPage = new LoginPage(driver);
			ProductListPage productListPage = loginPage.loginAndCheckElementVisibility();

			// Step 2: Verify product sorting by checking if the order is correct
			boolean isSortedCorrectly = productListPage.checkOrder(sortingMethod);
			Assert.assertTrue(isSortedCorrectly, "Products are not sorted correctly by: " + sortingMethod);
            AbstractComponents.logStep("TC[Product Listing Page Verification] : ✅ Product sorting test passed for method: " + sortingMethod);

		} catch (IOException | InterruptedException e) {
			// Step 3: Handle any exceptions and log failure
			System.err.println("❌ Product sorting test failed due to exception: " + e.getMessage());
			e.printStackTrace();
			Assert.fail("Product sorting test failed.");
		}
	}
	
	
	/**
	 * Test Case: Verify "Add to Cart" Button Functionality
	 * TC[Product Listing Page Verification] : 1-4
	 * <p>
	 * <b>Pre-requisites:</b>
	 * <ul>
	 * <li>User must be logged in before accessing the product list.</li>
	 * <li>Product list page must contain valid product elements (name, image, price, description, and "Add to Cart" button).</li>
	 * <li>Product data should be available in a JSON file, with the URL for the product accessible at index 0.</li>
	 * </ul>
	 *
	 * <p>
	 * <b>Test Steps:</b>
	 * <ol>
	 * <li>Retrieve the product URL from the JSON file (index 0).</li>
	 * <li>If URL is not available or empty, fail the test.</li>
	 * <li>Navigate to the login page and log in to proceed to the product list page.</li>
	 * <li>Wait for the product list page to load, ensuring all elements (product name, image, price, description, "Add to Cart" button) are present.</li>
	 * <li>Verify that the count of product names, images, prices, descriptions, and "Add to Cart" buttons match.</li>
	 * <li>Click each "Add to Cart" button and verify it changes to "Remove".</li>
	 * <li>If all buttons change to "Remove", assert the test as passed.</li>
	 * </ol>
	 *
	 * <p>
	 * <b>Expected Result:</b>
	 * <ul>
	 * <li>All product UI elements should match in count.</li>
	 * <li>All "Add to Cart" buttons should change to "Remove" after being clicked.</li>
	 * </ul>
	 */
	@Test
	public void verifyAddToCartButtonFunctionality() {
	    try {
	        // Retrieve product page URL from JSON (index 0 by default)
	        
	        AbstractComponents abstractComponents = new AbstractComponents(driver);
	        Assert.assertTrue(abstractComponents.checkCurrentURL(3));
            AbstractComponents.logStep("TC[Product Detail Page Verification] : ✅ Product Listing Page URL matches" );

	        // Navigate to login and go to product list page
	        LoginPage loginPage = new LoginPage(driver);
	        ProductListPage productListPage = loginPage.loginAndCheckElementVisibility();

	        // Wait for product elements to load
	        int nameCount = productListPage.getProductNameCount();
	        int imageCount = productListPage.getProductImageCount();
	        int priceCount = productListPage.getProductPriceCount();
	        int descCount = productListPage.getProductDescriptionCount();
	        int buttonCount = productListPage.getAddToCartButtonCount();
            AbstractComponents.logStep("TC[Product Detail Page Verification] : ✅ All products and required details are displayed." );

	        
	        // Assert all UI elements are present and counts match
	        Assert.assertEquals(nameCount, imageCount, "Product name/image count mismatch.");
	        Assert.assertEquals(nameCount, priceCount, "Product name/price count mismatch.");
	        Assert.assertEquals(nameCount, descCount, "Product name/description count mismatch.");
	        Assert.assertEquals(nameCount, buttonCount, "Product name/button count mismatch.");

	        // Check all "Add to cart" buttons change to "Remove" after clicking
	        boolean allButtonsChanged = productListPage.checkButtonTextChanging();
	        Assert.assertTrue(allButtonsChanged, "Not all 'Add to cart' buttons changed to 'Remove'.");
            AbstractComponents.logStep("TC[Product Detail Page Verification] : ✅ Add to cart is visible and label changes." );

	        System.out.println("✅ Product button functionality test passed. Total products: " + nameCount);

	    } catch (IOException | InterruptedException e) {
	        System.err.println("❌ Test failed due to exception: " + e.getMessage());
	        e.printStackTrace();
	        Assert.fail("Test failed due to an unexpected error.");
	    }
	}


	
	
	/**
	 * Test Case: Verify Adding Item to Cart Functionality
	 * TC[Cart Functionality Verification] : 1-4
	 * <p>
	 * <b>Pre-requisites:</b>
	 * <ul>
	 * <li>User must be logged in before proceeding to the product list page.</li>
	 * <li>Product list page must be available and contain valid products that can be added to the cart.</li>
	 * <li>The system should support adding and removing products from the cart.</li>
	 * </ul>
	 *
	 * <p>
	 * <b>Test Steps:</b>
	 * <ol>
	 * <li>Perform login and navigate to the product list page.</li>
	 * <li>Initialize the AddToCart page object to interact with the cart functionality.</li>
	 * <li>Add one product to the cart and verify that it was added successfully.</li>
	 * <li>Remove all products from the cart.</li>
	 * <li>Add four products to the cart and verify that all were added successfully.</li>
	 * <li>Remove all products from the cart again.</li>
	 * <li>Verify Burger Menu functionality by checking if all menu elements are present and functional.</li>
	 * <li>Close the Burger Menu after verification.</li>
	 * </ol>
	 *
	 * <p>
	 * <b>Expected Result:</b>
	 * <ul>
	 * <li>All operations (adding, removing products) should be executed without errors.</li>
	 * <li>The Burger Menu should open, display all required elements, and close properly.</li>
	 * </ul>
	 */
	@Test
	public void verifyAddingItemFunctionality() {
	    try {
	        // Step 1: Perform login and navigate to the product list page
	        LoginPage loginPage = new LoginPage(driver);
	        loginPage.loginAndCheckElementVisibility();

	        // Step 2: Initialize AddToCart page object and perform cart operations
	        AddToCart addToCart = new AddToCart(driver);

	        // Add one product to the cart
	        boolean isOneProductAdded = addToCart.addToCart(1);
	        Assert.assertTrue(isOneProductAdded, "Failed to add 1 product to cart.");
	        addToCart.removeAllProducts();
            AbstractComponents.logStep("TC[Cart Functionality Verification] : ✅ Cart count updates when adding one product." );

	        // Add four products to the cart
	        boolean areFourProductsAdded = addToCart.addToCart(4);
	        Assert.assertTrue(areFourProductsAdded, "Failed to add 4 products to cart.");
	        addToCart.removeAllProducts();
            AbstractComponents.logStep("TC[Cart Functionality Verification] : ✅ Cart count updates when adding multiple product." );

	        
	        // Verify Burger Menu functionality
	        addToCart.openBurgerMenu();
	        Assert.assertTrue(addToCart.checkBurgerMenuElementsExists(), "Burger menu elements are missing.");
            AbstractComponents.logStep("TC[Cart Funtionality Verification] : ✅ Burger menu elements are displayed properly." );

	        addToCart.closeBurgerMenu();
            AbstractComponents.logStep("TC[Cart Functionality Verification] : ✅ Burger menu close button works properly." );
	        System.out.println("✅ Add to cart functionality test passed.");

	    } catch (IOException | InterruptedException e) {
	        // Step 3: Handle any exceptions and log failure
	        System.err.println("❌ Add to cart functionality test failed due to exception: " + e.getMessage());
	        e.printStackTrace();
	        Assert.fail("Add to cart functionality test failed.");
	    }
	}


	/**
	 * Test to verify the product detail page, ensuring product details are correct
	 * and shopping badge updates correctly.
	 * TC[Product Detail Page Verification] : 1-5
	 * Preconditions: 1. User must be logged in. 2. Products must be added to the
	 * cart. 3. The product data should be fetched from a valid JSON file.
	 * 
	 * Steps: 1. Log in to the application. 2. Add a specified number of products to
	 * the cart. 3. Fetch product data from the JSON file. 4. Verify the product
	 * detail page for each added product. 5. Ensure product details are visible and
	 * the shopping badge updates correctly. 6. Navigate back to the product listing
	 * after checking each product.
	 * 
	 * @throws IOException          If there's an error reading the JSON file.
	 * @throws InterruptedException If the thread is interrupted during the test.
	 */
	@Test
	public void checkProductDetailPage() throws IOException, InterruptedException {
		// Step 1: Perform login and navigate to the product list page
		LoginPage loginPage = new LoginPage(driver);
		loginPage.loginAndCheckElementVisibility(); // Login to the system and verify element visibility post-login

		// Step 2: Add first 6 products to the cart
		AddToCart addToCart = new AddToCart(driver);
		int productNumber = 6; // Number of products to add to the cart
		addToCart.addToCart(productNumber); // Add product i to the cart
		
		
		// Step 3: Fetch product data from the JSON file using DataConverter
		ProductDetailPage productDetail = new ProductDetailPage(driver);
		DataConverter dataConverter = new DataConverter(driver);
		JsonNode productData = dataConverter.getProductDataFromJson(); // Fetch product data from the JSON file

		// Ensure product data is available
		if (productData != null) {
			int count = 0; // Track the number of products processed

			// Step 4: Verify product details for each added product
			for (JsonNode product : productData) {
				if (count >= productNumber) {
					break; // Stop once we have verified the specified number of products
				}

				// Verify details for the added products only
				LOGGER.info("Verifying product: " + product.get("name").asText());
				
				Assert.assertTrue(productDetail.verifyProductDetailPage(product)); // Check if the product detail page
																			// URL matches
				Assert.assertTrue(productDetail.checkProductDetailVisibility()); // Ensure all product details are
																					// visible
				Assert.assertTrue(productDetail.checkShoppingBadgeValue()); // Check if the shopping badge updates
																		// correctly

				// Step 5: Navigate back to the product listing page after checking the current
				// product
				productDetail.navigateBackToProductListing();

				count++; // Increment the product check count
			}
		} else {
			// If no product data is found, log a warning and fail the test
			LOGGER.warning("No product data available to verify.");
			Assert.fail("No product data found in the JSON file.");
		}
	}

	/**
	 * Test Case: Add to Cart and Verify Persistence After Login
	 * TC[Cart Page Verification] : 1 - 9
	 * <p>
	 * <b>Pre-requisites:</b>
	 * <ul>
	 * <li>Test user must be able to log in with valid credentials.</li>
	 * <li>Product list should be accessible after login.</li>
	 * <li>Each product should be uniquely identifiable and addable to the
	 * cart.</li>
	 * </ul>
	 *
	 * <p>
	 * <b>Test Data:</b> Supplied by ExcelData.class via @DataProvider:
	 * <ul>
	 * <li><b>productNumber</b>: The number of items to be added to the cart.</li>
	 * <li><b>removeProductNumber</b>: The number of items to be removed to verify
	 * persistence.</li>
	 * </ul>
	 *
	 * <p>
	 * <b>Test Steps:</b>
	 * <ol>
	 * <li>Log in with valid credentials.</li>
	 * <li>Add specified number of items to the cart.</li>
	 * <li>Navigate to the cart and verify that:
	 * <ul>
	 * <li>Cart elements (buttons, labels) are visible.</li>
	 * <li>URL matches the expected cart page.</li>
	 * <li>Cart contains correct items.</li>
	 * </ul>
	 * </li>
	 * <li>Verify that cart contents persist after logout and re-login, even after
	 * removing an item.</li>
	 * </ol>
	 *
	 * <p>
	 * <b>Expected Result:</b>
	 * <ul>
	 * <li>Cart elements are correctly displayed.</li>
	 * <li>Correct items are present in the cart.</li>
	 * <li>Cart maintains state after login/logout cycle.</li>
	 * </ul>
	 *
	 * @param productNumber       Number of items to be added to the cart.
	 * @param removeProductNumber Number of items to be removed to test persistence.
	 * @throws IOException          if reading from Excel data fails.
	 * @throws InterruptedException if thread sleep is interrupted during test
	 *                              execution.
	 */
	@Test(dataProvider = "productCartPageData", dataProviderClass = ExcelData.class)
	public void testAddToCartAndVerifyPersistence(String productNumber, String removeProductNumber)
			throws IOException, InterruptedException {

		// Step 1: Perform login and navigate to product list
		LoginPage loginPage = new LoginPage(driver);
		loginPage.loginAndCheckElementVisibility();

		// Step 2: Add items to the cart
		CartPage cartPage = new CartPage(driver);
		int productLimit = Integer.parseInt(productNumber);
		cartPage.addItemsToCart(productLimit);
		// Step 3: Verify visibility and correctness of cart elements and contents
		Assert.assertTrue(cartPage.areCartElementsVisibleAndValidateURL(),
				"Cart elements are not visible or URL mismatch.");
		AbstractComponents.logStep("TC[Cart Page Verification] : ✅ Product URL and elements are displayed.");

		Assert.assertTrue(cartPage.verifyCartContents(), "Cart items do not match added items.");
		AbstractComponents.logStep("TC[Cart Page Verification] : ✅ Product contents are displayed properly.");

		// Step 4: Verify cart state is persistent across login session
		Assert.assertTrue(cartPage.checkItemPersistenceAfterLogin(removeProductNumber),
				"Cart items were not persistent after login.");
		AbstractComponents.logStep("TC[Cart Page Verification] : ✅ Item persists even after logging out.");

		System.out.println("✅ Products were added, verified, and persisted successfully.");
	}
	
	/**
	 * Test Case: Verify Information Page Utilities
	 * TC[Checkout Process Verification] : 1-3
	 * <p>
	 * <b>Pre-requisites:</b>
	 * <ul>
	 * <li>User must be logged in and navigate to the information page.</li>
	 * <li>The information page should display the necessary utilities for the user.</li>
	 * </ul>
	 *
	 * <p>
	 * <b>Test Steps:</b>
	 * <ol>
	 * <li>Navigate to the information page after login.</li>
	 * <li>Verify that all utilities on the page are functioning as expected.</li>
	 * </ol>
	 *
	 * <p>
	 * <b>Expected Result:</b>
	 * <ul>
	 * <li>All utilities on the information page should be visible and functional.</li>
	 * </ul>
	 */
	@Test
	public void checkInformationPageUtilities() throws IOException, InterruptedException {
	    InformationPage informationPage = new InformationPage(driver);
	    Assert.assertTrue(informationPage.checkInformationUtilities());
	    System.out.println("✅ Information page utilities test passed.");
	}

	/**
	 * Test Case: Verify Checkout Overview Page
	 * TC[Checkout Overview Verification] : 1-5
	 * <p>
	 * <b>Pre-requisites:</b>
	 * <ul>
	 * <li>User must be logged in and have added items to the cart.</li>
	 * <li>The checkout overview page should display relevant details about the checkout process.</li>
	 * </ul>
	 *
	 * <p>
	 * <b>Test Steps:</b>
	 * <ol>
	 * <li>Navigate to the checkout overview page.</li>
	 * <li>Verify that the page displays the correct checkout information (e.g., items, prices, totals).</li>
	 * </ol>
	 *
	 * <p>
	 * <b>Expected Result:</b>
	 * <ul>
	 * <li>The checkout overview page should show all relevant details for the user.</li>
	 * </ul>
	 */
	@Test
	public void checkOutPageOverview() throws IOException, InterruptedException {
	    CheckoutOverview checkoutOverview = new CheckoutOverview(driver);
	    Assert.assertTrue(checkoutOverview.checkOutOverviewPage());
	    System.out.println("✅ Checkout overview page test passed.");
	}

	    

}
