package finalActivity.finalActivityEcommerce.testing;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import finalActivity.finalActivityEcommerce.pageObjects.OrderCompletion;
import finalActivity.finalActivityEcommerce.testComponents.BaseTest;


public class SubmitOrder extends BaseTest {


    
	/**
	 * Test Case: Verify Order Completion Flow
	 * TC[Login Page Verification] : 1 & 7 
	 * TC[Checkout Process Verification] : 11
	 * TC[Order Completion Verification] : 1-4
	 * <p>
	 * <b>Pre-requisites:</b>
	 * <ul>
	 * <li>User must be logged in and have added items to the cart.</li>
	 * <li>The order completion page should be accessible for the user to proceed with the order.</li>
	 * </ul>
	 *
	 * <p>
	 * <b>Test Steps:</b>
	 * <ol>
	 * <li>Navigate to the order completion page after adding items to the cart.</li>
	 * <li>Verify that the user is redirected to the correct page.</li>
	 * <li>Check that the order completion flow proceeds as expected.</li>
	 * </ol>
	 *
	 * <p>
	 * <b>Expected Result:</b>
	 * <ul>
	 * <li>The user should be redirected to the order completion page, and the process should complete successfully.</li>
	 * </ul>
	 */
	@Test
	public void orderCompletion() throws IOException, InterruptedException {
	    OrderCompletion orderCompletion = new OrderCompletion(driver);
	    Assert.assertTrue(orderCompletion.proceedPage());
	    System.out.println("✅ Order completion test passed.");
	}

   
    
    

}
    
