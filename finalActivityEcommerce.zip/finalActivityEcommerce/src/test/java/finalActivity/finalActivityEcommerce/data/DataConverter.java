package finalActivity.finalActivityEcommerce.data;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * DataConverter handles the extraction of user data from a webpage,
 * converts it into JSON format, and reads JSON data for automation.
 */
public class DataConverter {

    // Logger for tracking application flow and issues
    private static final Logger LOGGER = Logger.getLogger(DataConverter.class.getName());

    private final List<UserData> users = new ArrayList<>();

    // Web elements containing raw login credentials from UI
    @FindBy(xpath = "//div[@id='login_credentials']")
    private WebElement userName;

    @FindBy(xpath = "//div[@class='login_password']")
    private WebElement passWord;

    /**
     * Constructor initializes web elements using PageFactory.
     * 
     * @param driver WebDriver instance for element interaction
     */
    public DataConverter(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    /**
     * Fetches login credentials from UI, parses them,
     * and writes them to a JSON file.
     */
    public void fetchDataFromWeb() {
        try {
            String userNameText = userName.getText().trim();
            String passWordText = passWord.getText().trim();

            if (userNameText.isEmpty() || passWordText.isEmpty()) {
                throw new IllegalStateException("Login credentials not found on UI.");
            }

            String[] extractedUsers = extractUsers(userNameText);
            String validPassword = extractPassword(passWordText);

            for (String user : extractedUsers) {
                users.add(new UserData(user, validPassword));
                LOGGER.info("Captured - User: " + user + " | Password: " + validPassword);
            }

            convertDataToJSON("data.json");

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error fetching user credentials: " + e.getMessage(), e);
        }
    }

    /**
     * Extracts multiple usernames from raw string text.
     *
     * @param userText Raw user credential text from webpage
     * @return Array of usernames
     */
    private String[] extractUsers(String userText) {
        String[] userParts = userText.split("are:");
        if (userParts.length < 2) {
            throw new IllegalArgumentException("Invalid format for user data.");
        }
        return userParts[1].trim().split("\\n");
    }

    /**
     * Extracts password string from raw UI string.
     *
     * @param passwordText Raw password text from webpage
     * @return Extracted password
     */
    private String extractPassword(String passwordText) {
        String[] passParts = passwordText.split("users:");
        if (passParts.length < 2) {
            throw new IllegalArgumentException("Invalid format for password data.");
        }
        return passParts[1].trim();
    }

    /**
     * Converts the extracted user credentials into a JSON file.
     *
     * @param filePath Path to save JSON file
     */
    public void convertDataToJSON(String filePath) {
        if (users.isEmpty()) {
            LOGGER.warning("User list is empty. Skipping JSON write.");
            return;
        }

        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        try (FileWriter file = new FileWriter(filePath)) {
            gson.toJson(users, file);
            LOGGER.info("User data saved to JSON: " + filePath);
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Failed to write JSON file: " + e.getMessage(), e);
        }
    }

    /**
     * Reads the first user credentials object from the JSON file.
     * @param filePath 
     *
     * @return JsonNode of the first user object
     */
    public static JsonNode getFirstJsonObject(String filePath) {
        File jsonFile = new File(filePath);

        if (!jsonFile.exists()) {
            LOGGER.warning("Missing JSON file: " + jsonFile.getAbsolutePath());
            return null;
        }

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonArray = objectMapper.readTree(jsonFile);

            if (jsonArray.isArray() && jsonArray.size() > 0) {
                return jsonArray.get(0);
            } else {
                LOGGER.warning("Login JSON is empty or not formatted as array.");
            }
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error reading login JSON: " + e.getMessage(), e);
        }

        return null;
    }

    /**
     * Loads the product data from product.json file.
     *
     * @return JsonNode containing the product list
     */
    public static JsonNode getJsonData() {
        File jsonFile = new File("product.json");

        if (!jsonFile.exists()) {
            LOGGER.warning("Product JSON not found: " + jsonFile.getAbsolutePath());
            return null;
        }

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonData = objectMapper.readTree(jsonFile);
            return jsonData.has("products") ? jsonData.get("products") : null;
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Failed to read product JSON: " + e.getMessage(), e);
        }

        return null;
    }

    /**
     * Prints the selected field (id, name, url) of all products in the given JsonNode.
     *
     * @param productData JsonNode containing product array
     * @param field Field name to print (id, name, url)
     */
    public static void printProductField(JsonNode productData, String field) {
        if (productData == null) {
            LOGGER.warning("No product data available.");
            return;
        }

        if (!field.equals("id") && !field.equals("name") && !field.equals("url")) {
            LOGGER.warning("Invalid field name: " + field);
            return;
        }

        for (JsonNode product : productData) {
            try {
                String value = getFieldValue(product, field);
                LOGGER.info(field.toUpperCase() + ": " + value + "\n-------------");
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error reading field '" + field + "': " + e.getMessage(), e);
            }
        }
    }

    /**
     * Dynamically retrieves a specified field from a product node.
     *
     * @param product Product JSON node
     * @param field   Field to extract (id, name, url)
     * @return Field value as String
     */
    private static String getFieldValue(JsonNode product, String field) {
        switch (field) {
            case "id":
                return String.valueOf(product.get("id").asInt());
            case "name":
                return product.get("name").asText();
            case "url":
                return product.get("url").asText();
            default:
                throw new IllegalArgumentException("Invalid product field requested.");
        }
    }

    /**
     * Helper method to retrieve JSON product data from internal method.
     *
     * @return JsonNode with product array
     */
    public JsonNode getProductDataFromJson() {
        return DataConverter.getJsonData();
    }

    /**
     * Gets the URL at a specific index from checkOut.json array.
     *
     * @param index Index in the JSON array
     * @return URL string if found, else null
     */
    public static String getUrlAtIndex(int index) {
        File jsonFile = new File("url.json");

        if (!jsonFile.exists()) {
            LOGGER.warning("Checkout JSON file missing: " + jsonFile.getAbsolutePath());
            return null;
        }

        try {
        	 ObjectMapper objectMapper = new ObjectMapper();
             JsonNode jsonArray = objectMapper.readTree(jsonFile);

             // Debug: Print the entire JSON content to verify it's parsed correctly
             System.out.println(jsonArray.toString());

             if (jsonArray.isArray() && jsonArray.has(index)) {
                 System.out.println(jsonArray.get(index).asText());
                 return jsonArray.get(index).get("url").asText();  // Return the URL directly
             } else {
                LOGGER.warning("Invalid index or checkout data structure.");
            }
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error reading checkout JSON: " + e.getMessage(), e);
        }

        return null;
    }

    // Inner class representing a user with email and password
    static class UserData {
        public UserData(String email, String password) {
        }
    }
}
