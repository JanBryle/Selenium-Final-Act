package finalActivity.finalActivityEcommerce.data;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class ExcelData {

    private static final String FILE_PATH = "C:\\Users\\janbr\\Stratpoint Projects\\Selenium\\Final Project.xlsx";

    @DataProvider(name = "loginNegativeData")
    public Object[][] getLoginData() throws IOException {
        return readExcelData(6, 0, 2); // Reads 6 test cases from sheet index 0, starting from column 2
    }
    

    @DataProvider(name = "productListDataOrder")
    public Object[][] getProductListOrder() throws IOException {
        return readExcelData(4, 1, 1); // Reads 6 test cases from sheet index 1, starting from column 2
    }
    
    @DataProvider(name = "productCartPageData")
    public Object[][] getCartPageData() throws IOException {
        return readExcelData(2, 2, 1); // Reads 6 test cases from sheet index 1, starting from column 2
    }
    
    @DataProvider(name = "productInformationPageErrorValidation")
    public Object[][] getInformationPageError() throws IOException {
    	 Object[][] data = readExcelData(7, 3, 1);
    	    
    	    System.out.println("Data Provider Rows: " + data.length);
    	    for (Object[] row : data) {
    	        System.out.println(Arrays.toString(row));
    	    }
    	    
    	    return data;    }


    /**
     * Reads test data from an Excel sheet dynamically.
     *
     * @param testCases    Number of test cases to fetch
     * @param sheetIndex   Sheet index to read from
     * @param startColumn  Column index where test data begins
     * @return Object[][]  2D array containing test data
     * @throws IOException if file read operation fails
     */
    private Object[][] readExcelData(int testCases, int sheetIndex, int startColumn) throws IOException {
        try (FileInputStream fis = new FileInputStream(FILE_PATH);
             XSSFWorkbook workbook = new XSSFWorkbook(fis)) {

            XSSFSheet sheet = workbook.getSheetAt(sheetIndex);

            int totalRows = sheet.getLastRowNum();
            int totalColumns = sheet.getRow(0).getLastCellNum();
            System.out.println(totalRows);
            System.out.println(totalColumns);

            int availableTestCases = countValidTestCases(sheet, totalColumns);

            int finalTestCount = Math.min(testCases, availableTestCases);
            System.out.println("✅ Executing " + finalTestCount + " out of " + availableTestCases + " test cases.");

            Object[][] data = new Object[finalTestCount][totalRows];
            System.out.println(data.length);
            for (int i = 0; i < finalTestCount; i++) {
                for (int j = 0; j < totalRows; j++) {
                data[i][j] = getFormattedCellValue(sheet, j+1, i + startColumn);
                System.out.print(data[i][j] + "|");
                }
                System.out.println("");

               
            }
            return data;
        }
    }

    /**
     * Counts the number of valid test cases based on non-empty columns.
     *
     * @param sheet        Excel sheet
     * @param totalColumns Total number of columns
     * @return Number of valid test cases
     */
    private int countValidTestCases(XSSFSheet sheet, int totalColumns) {
        DataFormatter formatter = new DataFormatter();
        int count = 0;

        for (int i = 1; i < totalColumns; i++) {
            if (!formatter.formatCellValue(sheet.getRow(0).getCell(i)).trim().isEmpty()) {
                count++;
            }
        }
        return count;
    }

    /**
     * Fetches and formats a cell value while handling "N/A" as an empty string.
     *
     * @param sheet Excel sheet
     * @param row   Row index
     * @param col   Column index
     * @return Formatted cell value
     */
    private String getFormattedCellValue(XSSFSheet sheet, int row, int col) {
        DataFormatter formatter = new DataFormatter();
        if (sheet.getRow(row) == null || sheet.getRow(row).getCell(col) == null) {
            return ""; // Return an empty string instead of crashing
        }
        String value = formatter.formatCellValue(sheet.getRow(row).getCell(col)).trim();
        return value.equalsIgnoreCase("N/A") ? "" : value;
    }
}
